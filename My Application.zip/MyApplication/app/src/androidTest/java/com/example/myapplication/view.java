package com.example.myapplication;

public class view {
}
